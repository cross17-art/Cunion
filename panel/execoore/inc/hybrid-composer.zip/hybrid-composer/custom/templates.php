<?php
/*
=============================================================================
PAGE TEMPLATES
=============================================================================

This file contain the templates for Hybrid Composer.
The templates will be available in every page and post type by click the top right button "Templates".
You can add here every page. To get the template code to add to the array below select "Classic" composer mode
on top right area and copy the code of the main editor.

Documentation: wordpress.framework-y.com/advanced-api-documentation/#custom-theme

*/

$HC_TEMPLATES = array(
	'coming_soon' => ''
);

?>

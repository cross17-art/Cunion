<?php
session_start();
$_SESSION['logged'] = true;
$_SESSION['user_email'] = 'wydebinance@gmail.com';
?>
<script>
    location.href = "http://cunion.io/client/cabinet/cabinet.php"
</script>

<?php
session_start();
include ("classes/user.php");
include ("classes/MasterHandler.php");



//
//$masterPortfolio = MasterHandler::GetKucoinMasterPortfolio(134);
//
//foreach ($masterPortfolio as $portfolio){
//    echo ('<div style="border:2px solid red">');
//    var_dump($portfolio);
//    echo ('</div>');
//}
//


echo (bcmod(5,5));
echo (bcmod(6,5));
echo (bcmod(7,5));
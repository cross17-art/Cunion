<?php


?>

<div class="container-fluid p-0">
    <div class="row">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Traders</h5>
                <h6 class="card-subtitle text-muted">Here user can select which master to connect</h6>
            </div>
            <table master-table class="table" style="text-align: center">
                <thead>
                    <tr>
                        <th>Trader</th>
                        <th>Portfolio</th>
                        <th style="width:370px">Balance History</th>
                        <th>ROI%</th>
                        <th>Followers / Rating / Total Investments</th>
                    </tr>
                </thead>
                <tbody style="text-align: center">
                <?php
                /**
                 * @var array $allKucoinMasters
                 * @var User $user
                 */
                foreach ($allKucoinMasters as $kucoinMaster) {

                    $masterId = $kucoinMaster["user_id"];
                    $masterEmail = $kucoinMaster["email"];
                    $telegram = $kucoinMaster["telegram"];
                    $roi = $kucoinMaster["roi"];
                    $min_dep = $kucoinMaster["need_balance"];
                    $rate = $kucoinMaster["rate"];
                    $nickname = $kucoinMaster['nickname'] == null ? "no_name" : $kucoinMaster['nickname'];

                    $user->GetConnections('kucoin');
                    $connection = $user->GetConnectionByMasterID('kucoin', $masterId);
                    ?>
                    <tr master-template-tr master-id="<?= $masterId ?>" style="<?= $user->IsConnectedToMaster('kucoin', $masterId) ? " background-color: #1f9bcf1c; border: 2px solid #1f9bcf; " : " " ?> <?= $kucoinMaster['user_id'] == $user->id ? " background-color: #47ae6d30" : "" ?>">
                        <hr style="display: none" master-table-hr>
                        <!--                                        <td>--><? //= $masterEmail ?><!--</td>-->
                        <td profile>
                            <a href="http://cunion.io/client/cabinet/cabinet_master_page.php?master-id=<?= $masterId ?>"><?= $nickname ?></a>
                            <?php if ($user->IsConnectedToMaster('kucoin', $masterId)) { ?>
                                <div><span class="badge bg-info" style="padding: 5px; margin-top: 5px">Connected</span></div>
                            <?php } ?>

                        </td>

                        <td portfolio>
                            <canvas style="width: 120px; height: 70px; display: block; margin: auto" id="chartjs-bars-<?= $masterEmail ?>" chart="master_portfolio" master-id="<?= $masterId ?>"></canvas>
                        </td>

                        <td balance>
                            <canvas style="margin: auto" id="chartjs-line-<?= $masterEmail ?>" chart="master_balance" master-id="<?= $masterId ?>"></canvas>
                        </td>

                        <td roi>
                            <div>
                                <div roi-per-day class="trd_roi_stat trd_tooltip">
                                    <span class="trd_tooltiptext">Roi Per Day</span>
                                    <svg upper-daily-arrow style="transform: scale(1.5); display: none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-up align-middle me-2 trd_roi_stat_block table_roi_icon">
                                        <polyline arrow_x2 points="17 11 12 6 7 11"></polyline>
                                        <polyline arrow_x1 points="17 18 12 13 7 18"></polyline>
                                    </svg>
                                    <svg down-daily-arrow style="transform: scale(1.5); display: none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-down align-middle me-2 trd_roi_stat_block table_roi_icon">
                                        <polyline arrow_x2  points="7 13 12 18 17 13"></polyline>
                                        <polyline arrow_x1 points="7 6 12 11 17 6"></polyline>
                                    </svg>
                                    <div daily-profit style="width: 140px" class="trd_roi_stat_block">

                                    </div>
                                    <div style="display: inherit"> per day</div>
                                </div>
                            </div>

                            <div>
                                <div roi-per-week class="trd_roi_stat trd_tooltip">
                                    <span class="trd_tooltiptext">Roi Per Week</span>
                                    <svg upper-weekly-arrow style="transform: scale(1.5); display: none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-up align-middle me-2 trd_roi_stat_block table_roi_icon">
                                        <polyline arrow_x2 points="17 11 12 6 7 11"></polyline>
                                        <polyline arrow_x1 points="17 18 12 13 7 18"></polyline>
                                    </svg>
                                    <svg down-weekly-arrow style="transform: scale(1.5); display: none" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-down align-middle me-2 trd_roi_stat_block table_roi_icon">
                                        <polyline arrow_x2  points="7 13 12 18 17 13"></polyline>
                                        <polyline arrow_x1 points="7 6 12 11 17 6"></polyline>
                                    </svg>
                                    <div weekly-profit style="width: 140px" class="trd_roi_stat_block">

                                    </div>
                                    <div style="display: inherit"> per 7 days</div>
                                </div>
                            </div>


                            <style>
                                .trd_roi_stat {
                                    width: 200px;
                                    margin: auto;
                                    margin-bottom: 10px;
                                }

                                .trd_roi_stat_block {
                                    display: block;
                                    float: left;
                                }

                                .table_roi_icon {
                                    margin-right: 5px;
                                }

                                .arrow-slow {

                                }

                            </style>
                        </td>

                        <td statistic>
                            <div class="trd_tooltip">
                                <i class="align-middle me-2 fas fa-fw fa-users" style="width: 25px;"></i> <span users_count class="align-middle">0</span> <span class="trd_tooltiptext" style="font-size: 0.7em">Total investors</span>
                            </div>

                            <div style="margin-top: 10px">
                                <div class="trd_tooltip">
                                    <?= $rate . "  " ?><?php
                                    $intRate = intval($rate);
                                    $rest = $rate - $intRate;
                                    for ($i = 0; $i < $intRate; $i++) {
                                        echo('<i class="align-middle me-2 fas fa-fw fa-star"></i>');
                                    }
                                    if ($rest != 0) {
                                        echo('<i class="align-middle me-2 fas fa-fw fa-star-half-alt"></i>');
                                    }
                                    if ($rate == 0) {
                                        echo('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star align-middle me-2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>');
                                    }
                                    ?>
                                    <span class="trd_tooltiptext" style="font-size: 0.7em">Rating</span>
                                </div>
                            </div>

                            <div>
                                <div class="input-group mb-3 trd_tooltip" style="margin: auto; display: block; width: fit-content; margin-top: 20px; ">
                                    <span total_investment class="input-group-text" style="font-size: 16px;"> 0 USDT </span> <span class="trd_tooltiptext" style="font-size: 0.7em">Total Investments</span>
                                </div>
                            </div>


                        </td>
                    </tr>
                    <?php

                } ?>
                </tbody>
            </table>

            <style>
                [total_investment] {
                    color: #4bbf73;
                    background-color: #4bbf732d;;
                }

                /* Tooltip container */
                .trd_tooltip {
                    position: relative;
                    display: inline-block;
                }

                /* Tooltip text */
                .trd_tooltip .trd_tooltiptext {
                    visibility: hidden;
                    width: 120px;
                    background-color: black;
                    color: #fff;
                    text-align: center;
                    padding: 5px 0;
                    border-radius: 6px;

                    /* Position the tooltip text - see examples below! */
                    position: absolute;
                    z-index: 1;
                }

                /* Show the tooltip text when you mouse over the tooltip container */
                .trd_tooltip:hover .trd_tooltiptext {
                    visibility: visible;
                }

            </style>


        </div>
    </div>

</div>


<script>
    // document.addEventListener("DOMContentLoaded", function () {
    //     document.querySelectorAll("[master-template-tr]").forEach((elem) => {
    //         elem.addEventListener("click", () => {
    //             console.log(elem)
    //             let target = event.target;
    //
    //             let masterId = elem.getAttribute("master-id");
    //             console.log(target);
    //             if (event.target.getAttribute("profile") !== null) {
    //                 location.href = "http://cunion.io/client/cabinet/cabinet_master_page.php?master-id=" + masterId;
    //             } else {
    //                 event.preventDefault();
    //             }
    //
    //         });
    //
    //     })
    // })

</script>

<style>
    @media screen and (min-width: 300px) and (max-width: 600px)  {
        [master-template-tr]{
            display: grid;
        }

        table[master-table] > thead > tr{
            display: grid;
        }

        table[master-table] > thead > tr > th{
            width: 100% !important;
        }

        table[master-table] > tbody > tr{
            border: 1px solid #8255fd;
        }

        table[master-table] > tbody > tr > td{
            margin:auto;
            width: 100%;

        }
    }

    @media screen and (min-width: 600px) and (max-width: 1400px)  {
        [master-template-tr]{
            display: grid;
        }

        table[master-table] > thead > tr{
            display: grid;
        }

        table[master-table] > thead > tr > th{
            width: 100% !important;
        }

        table[master-table] > tbody > tr{
            border: 1px solid #8255fd;
        }

        table[master-table] > tbody > tr > td{
            margin:auto;
            width: 100%;
        }


        table[master-table] > tbody > tr[master-template-tr]{
            height: 420px;
        }

        table[master-table] > tbody > tr > td{
            border: 0;
        }

        table[master-table] > tbody > tr > td[profile]{
           border: 1px solid #545968;
        }

        table[master-table] > tbody > tr > td[portfolio]{
            position: relative;
            left: -110px;
            top: 25px;
        }


        table[master-table] > tbody > tr > td[balance]{
            position: relative;
            left: 110px;
            top: -95px;
        }

        table[master-table] > tbody > tr > td[roi]{
            position: relative;
            top: -100px;
            left: -100px;

        }

        table[master-table] > tbody > tr > td[statistic]{
            position: relative;
            top: -255px;
            left: 125px;

        }

        [master-table-hr]{
            width: 95%;
            margin: auto;
            color: #545968;
            position: relative;
            top: 150px;
            display: block;

        }
    }

</style>

<script>
    document.addEventListener('DOMContentLoaded', function (){
        document.querySelectorAll('.table_roi_icon').forEach((icon)=>{
            let arrow_x1 = icon.querySelector("[arrow_x1]");
            let arrow_x2 = icon.querySelector("[arrow_x2]");

            setInterval(()=>{
                setTimeout(() => {
                    arrow_x1.style.display = "block";
                    setTimeout(()=>{
                        arrow_x2.style.display = "block";
                        setTimeout(()=>{
                            arrow_x2.style.display = "none";
                            arrow_x1.style.display = "none";
                        },2000)
                    },200)
                }, 200);
            }, 2400)
        })
    })

</script>
<?php


class MasterAccount {
    public $type; //kucoin, binance, ftx....
    public $id;
    public $deposit;
    public $roi;



    public function __construct($_type,$_id, $_deposit, $_roi){
        $this->type = $_type;
        $this->id = $_id;
        $this->deposit = $_deposit;
        $this->roi = $_roi;
    }
}